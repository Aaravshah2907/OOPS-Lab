package com.passwordvalidator;


public class PasswordValidator {

    public boolean isValidPassword(String password) {
        // Check length
        if (password.length() < 8) {
            return false;
        }

        // Check for at least one uppercase letter
        if (!password.matches(".*[A-Z].*")) {
            return false;
        }

        // Check for at least one lowercase letter
        if (!password.matches(".*[a-z].*")) {
            return false;
        }

        // Check for at least one digit
        if (!password.matches(".*\\d.*")) {
            return false;
        }

        // Check for at least one special character
        if (!password.matches(".*[!@#$%^&*].*")) {
            return false;
        }

        return true;
    }
    
    public String getPasswordStrength(String password) {
        if (isValidPassword(password)) {
            return "Strong";
        } else if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*[a-z].*")) {
            return "Medium";
        } else {
            return "Weak";
        }
    }
}



