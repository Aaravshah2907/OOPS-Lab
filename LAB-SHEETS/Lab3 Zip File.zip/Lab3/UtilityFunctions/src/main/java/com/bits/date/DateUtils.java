package com.bits.date;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    /**
     * Checks if a given year is a leap year.
     *
     * @param year The year to check.
     * @return True if the year is a leap year, false otherwise.
     */
    public boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    /**
     * Returns the day of the week for a given date.
     *
     * @param year  The year.
     * @param month The month (1-12).
     * @param day   The day of the month.
     * @return The day of the week (0 for Sunday, 1 for Monday, etc.).
     */
    public int getDayOfWeek(int year, int month, int day) {
        LocalDate date = LocalDate.of(year, month, day);
        return date.getDayOfWeek().getValue() % 7; // Convert to 0-6 range (Sunday = 0)
    }

    /**
     * Formats a date as "YYYY-MM-DD".
     *
     * @param year  The year.
     * @param month The month (1-12).
     * @param day   The day of the month.
     * @return The formatted date string.
     */
    public String formatDate(int year, int month, int day) {
        LocalDate date = LocalDate.of(year, month, day);
        return date.format(DateTimeFormatter.ISO_DATE);
    }
}
