package com.bits.math;

public class MathUtils {

    /**
     * Calculates the factorial of a non-negative integer.
     */
    public int factorial(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Input must be non-negative.");
        }
        if (n == 0 || n == 1) {
            return 1;
        }
        int result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }

    /**
     * Checks if a number is prime.
     */
    public boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Generates the first n Fibonacci numbers using recursion.
     */
    public int[] generateFibonacci(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Input must be non-negative.");
        }
        int[] fibonacci = new int[n];
        for (int i = 0; i < n; i++) {
            fibonacci[i] = fibRecursive(i); // Use recursion to calculate each Fibonacci number
        }
        return fibonacci;
    }

    /**
     * Recursive helper method to calculate the nth Fibonacci number.
     */
    private int fibRecursive(int n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return fibRecursive(n - 1) + fibRecursive(n - 2); // Inefficient recursion
    }

    /**
     * Computes the greatest common divisor (GCD) of two integers.
     */
    public int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }
}