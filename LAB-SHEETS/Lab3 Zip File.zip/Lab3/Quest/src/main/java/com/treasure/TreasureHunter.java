package com.treasure;

public class TreasureHunter {

    private int x; // Current x-coordinate
    private int y; // Current y-coordinate
    private final int mapSize; // Size of the map (grid)

    public TreasureHunter(int mapSize) {
        this.mapSize = mapSize;
        this.x = 0; // Start at (0, 0)
        this.y = 0;
    }

    // Move the adventurer in a direction (N, S, E, W)
    public void move(char direction) {
        switch (direction) {
            case 'N': if (y < mapSize - 1) y++; break;
            case 'S': if (y > 0) y--; break;
            case 'E': if (x < mapSize - 1) x++; break;
            case 'W': if (x > 0) x--; break;
            default: throw new IllegalArgumentException("Invalid direction");
        }
    }

    // Check if the adventurer has found the treasure (at a specific location)
    public boolean hasFoundTreasure(int treasureX, int treasureY) {
        return x == treasureX && y == treasureY;
    }

    // Validate if a move is within the bounds of the map
    public boolean isValidMove(char direction) {
        switch (direction) {
            case 'N': return y < mapSize - 1;
            case 'S': return y > 0;
            case 'E': return x < mapSize - 1;
            case 'W': return x > 0;
            default: throw new IllegalArgumentException("Invalid direction");
        }
    }

    // Simulate a random move (N, S, E, W)
    public char simulateRandomMove() {
        char[] directions = {'N', 'S', 'E', 'W'};
        return directions[(int) (Math.random() * directions.length)];
    }
    
    //getter functions
    public int getX() {return x;}
    public int getY() {return y;}
}
