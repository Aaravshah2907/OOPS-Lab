package com.bits.stringutils;

public class StringUtils {

    /**
     * Checks if a string is a palindrome (reads the same backward as forward).
     *
     * @param str The input string.
     * @return True if the string is a palindrome, false otherwise.
     */
    public boolean isPalindrome(String str) {
        if (str == null) {
            return false; // Handle null input
        }
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equals(reversed);
    }

    /**
     * Reverses the given string.
     *
     * @param str The input string.
     * @return The reversed string.
     * @throws IllegalArgumentException if the input string is null.
     */
    public String reverse(String str) {
        if (str == null) {
            throw new IllegalArgumentException("Input cannot be null");
        }
        return new StringBuilder(str).reverse().toString();
    }

    /**
     * Counts the number of vowels in a string.
     *
     * @param str The input string.
     * @return The number of vowels in the string.
     */
    public int countVowels(String str) {
        if (str == null) {
            return 0; // Handle null input
        }
        return (int) str.toLowerCase().chars()
                .filter(c -> "aeiou".indexOf(c) != -1)
                .count();
    }
}