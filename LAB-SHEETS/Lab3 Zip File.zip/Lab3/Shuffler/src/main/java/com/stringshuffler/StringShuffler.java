package com.stringshuffler;

public class StringShuffler {
	
	//shuffle input string
	public String shuffleString(String input) {
	    char[] characters = input.toCharArray();
	    for (int i = 0; i < characters.length; i++) {
	        int randomIndex = (int) (Math.random() * characters.length);
	        char temp = characters[i];
	        characters[i] = characters[randomIndex];
	        characters[randomIndex] = temp;
	    }
	    return new String(characters);
	}
	
	//derangement of string
	public String shuffleStringDerangement(String input) {
	    char[] characters = input.toCharArray();
	    boolean isDerangement;
	    do {
	        isDerangement = true;
	        for (int i = 0; i < characters.length; i++) {
	            int randomIndex = (int) (Math.random() * characters.length);
	            char temp = characters[i];
	            characters[i] = characters[randomIndex];
	            characters[randomIndex] = temp;
	        }
	        // Check if any character is in its original position
	        for (int i = 0; i < characters.length; i++) {
	            if (characters[i] == input.charAt(i)) {
	                isDerangement = false;
	                break;
	            }
	        }
	    } while (!isDerangement); // Repeat until derangement is achieved
	    return new String(characters);
	}
}
